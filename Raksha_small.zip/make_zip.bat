@echo off
title Creating Raksha Project ZIP Package
echo =====================================================================
echo           Packaging Raksha Emergency Response Project
echo =====================================================================
echo.
echo Compressing project files (excluding node_modules)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$src = '%~dp0'; $zipDownloads = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads\Raksha.zip'; $zipDesk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Raksha.zip'; $zipLocal = Join-Path $src 'Raksha_Latest.zip'; Add-Type -AssemblyName System.IO.Compression.FileSystem; $tmp = Join-Path $env:TEMP ('Raksha_Pkg_' + (Get-Random)); New-Item -ItemType Directory -Path $tmp -Force | Out-Null; @('src','public','server','dist','index.html','package.json','package-lock.json','postcss.config.js','README.md','start.bat','make_zip.bat','tailwind.config.js','vite.config.js','tile_carto.png','tile_esri.jpg') | ForEach-Object { $p = Join-Path $src $_; if (Test-Path $p) { Copy-Item $p (Join-Path $tmp $_) -Recurse -Force } }; if (Test-Path $zipDownloads) { Remove-Item $zipDownloads -Force }; [System.IO.Compression.ZipFile]::CreateFromDirectory($tmp, $zipDownloads, [System.IO.Compression.CompressionLevel]::Optimal, $false); if (Test-Path (Split-Path $zipDesk)) { Copy-Item $zipDownloads $zipDesk -Force }; Copy-Item $zipDownloads $zipLocal -Force; Remove-Item $tmp -Recurse -Force; Write-Host ('SUCCESS: Raksha.zip created at: ' + $zipDownloads + ' and ' + $zipLocal) -ForegroundColor Green"
echo.
echo [DONE] Archive generated successfully!
echo Files saved to:
echo  - %USERPROFILE%\Downloads\Raksha.zip
echo  - %USERPROFILE%\Desktop\Raksha.zip
echo  - %~dp0Raksha_Latest.zip
echo.
pause
